import java.util.Scanner;
import java.util.ArrayList;
import classes.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int choice =0;
        ArrayList<Train> Train=new ArrayList<>();
        boolean exit = true;
        while (exit){
            System.out.println("1. To add");
            System.out.println("2. To delete");
            System.out.println("3. Show all");
            System.out.println("0. Exit");
            choice = sc.nextInt();
            switch (choice){
                case (1):
                    boolean check=false;
                    System.out.println("Input name:");
                    String name=sc.next();
                    System.out.println("Choose a train class");
                    System.out.println("1. Choose for Class A(30 cars)");
                    System.out.println("2. Choose for Class B(20 cars)");
                    System.out.println("3. Choose for Class C(10 cars)");
                    System.out.println("0. Exit)");
                    choice = sc.nextInt();
                    switch (choice) {
                        case (1):
                            System.out.println("Input car:");
                            int car = sc.nextInt();
                            while (car > 30) {
                                System.out.println("This car does not exist");
                                car = sc.nextInt();
                            }
                            System.out.println("Choose a train class");
                            System.out.println("1. Choose for Class Lux(10 seats)");
                            System.out.println("2. Choose for Class Coupe(30 seats)");
                            System.out.println("3. Choose for Class Plascart(50 seats)");
                            System.out.println("0. Exit)");
                            choice = sc.nextInt();
                            switch (choice) {
                                case (1):
                                    System.out.println("Input seat:");
                                    int seat = sc.nextInt();
                                    while (seat > 10) {
                                        System.out.println("This seat does not exist");
                                        seat = sc.nextInt();
                                    }
                                    for (int i = 0; i < Train.size(); ++i) {
                                        if (car == Train.get(i).getCar()) {
                                            if (seat == Train.get(i).getSeat()) {
                                                System.out.println("This seat is already taken ඞ");
                                                check = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (check == false) {
                                        Train.add(new Train(name, car, seat));
                                    }
                                    break;
                                case (2):
                                    System.out.println("Input seat:");
                                    int seat2 = sc.nextInt();
                                    while (seat2 > 30) {
                                        System.out.println("This seat does not exist");
                                        seat2 = sc.nextInt();
                                    }
                                    for (int i = 0; i < Train.size(); ++i) {
                                        if (car == Train.get(i).getCar()) {
                                            if (seat2 == Train.get(i).getSeat()) {
                                                System.out.println("This seat is already taken ඞ");
                                                check = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (check == false) {
                                        Train.add(new Train(name, car, seat2));
                                    }
                                    break;
                                case (3):
                                    System.out.println("Input seat:");
                                    int seat3 = sc.nextInt();
                                    while (seat3 > 50) {
                                        System.out.println("This seat does not exist");
                                        seat3 = sc.nextInt();
                                    }
                                    for (int i = 0; i < Train.size(); ++i) {
                                        if (car == Train.get(i).getCar()) {
                                            if (seat3 == Train.get(i).getSeat()) {
                                                System.out.println("This seat is already taken ඞ");
                                                check = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (check == false) {
                                        Train.add(new Train(name, car, seat3));
                                    }
                                    break;
                                case (0):
                                    exit = false;
                                    break;
                                default:
                                    System.out.println("Incorrect choice, try again");
                            }
                            break;
                        case (2):
                            System.out.println("Input car:");
                            int car2 = sc.nextInt();
                            while (car2 > 20) {
                                System.out.println("This car does not exist");
                                car2 = sc.nextInt();
                            }
                            System.out.println("Choose a train class");
                            System.out.println("1. Choose for Class Lux(10 seats)");
                            System.out.println("2. Choose for Class Coupe(30 seats)");
                            System.out.println("3. Choose for Class Plascart(50 seats)");
                            System.out.println("0. Exit)");
                            choice = sc.nextInt();
                            switch (choice) {
                                case (1):
                                    System.out.println("Input seat:");
                                    int seat = sc.nextInt();
                                    while (seat > 10) {
                                        System.out.println("This seat does not exist");
                                        seat = sc.nextInt();
                                    }
                                    for (int i = 0; i < Train.size(); ++i) {
                                        if (car2 == Train.get(i).getCar()) {
                                            if (seat == Train.get(i).getSeat()) {
                                                System.out.println("This seat is already taken ඞ");
                                                check = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (check == false) {
                                        Train.add(new Train(name, car2, seat));
                                    }
                                    break;
                                case (2):
                                    System.out.println("Input seat:");
                                    int seat1 = sc.nextInt();
                                    while (seat1 > 30) {
                                        System.out.println("This seat does not exist");
                                        seat1 = sc.nextInt();
                                    }
                                    for (int i = 0; i < Train.size(); ++i) {
                                        if (car2 == Train.get(i).getCar()) {
                                            if (seat1 == Train.get(i).getSeat()) {
                                                System.out.println("This seat is already taken ඞ");
                                                check = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (check == false) {
                                        Train.add(new Train(name, car2, seat1));
                                    }
                                    break;
                                case (3):
                                    System.out.println("Input seat:");
                                    int seat3 = sc.nextInt();
                                    while (seat3 > 50) {
                                        System.out.println("This seat does not exist");
                                        seat3 = sc.nextInt();
                                    }
                                    for (int i = 0; i < Train.size(); ++i) {
                                        if (car2 == Train.get(i).getCar()) {
                                            if (seat3 == Train.get(i).getSeat()) {
                                                System.out.println("This seat is already taken ඞ");
                                                check = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (check == false) {
                                        Train.add(new Train(name, car2, seat3));
                                    }
                                    break;
                                case (0):
                                    exit = false;
                                    break;
                                default:
                                    System.out.println("Incorrect choice, try again");
                            }
                        case (3):
                            System.out.println("Input car:");
                            int car3 = sc.nextInt();
                            while (car3 > 10) {
                                System.out.println("This car does not exist");
                                car3 = sc.nextInt();
                            }
                            System.out.println("Choose a train class");
                            System.out.println("1. Choose for Class Lux(10 seats)");
                            System.out.println("2. Choose for Class Coupe(30 seats)");
                            System.out.println("3. Choose for Class Plascart(50 seats)");
                            System.out.println("0. Exit)");
                            choice = sc.nextInt();
                            switch (choice) {
                                case (1):
                                    System.out.println("Input seat:");
                                    int seat = sc.nextInt();
                                    while (seat > 10) {
                                        System.out.println("This seat does not exist");
                                        seat = sc.nextInt();
                                    }
                                    for (int i = 0; i < Train.size(); ++i) {
                                        if (car3 == Train.get(i).getCar()) {
                                            if (seat == Train.get(i).getSeat()) {
                                                System.out.println("This seat is already taken ඞ");
                                                check = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (check == false) {
                                        Train.add(new Train(name, car3, seat));
                                    }
                                    break;
                                case (2):
                                    System.out.println("Input seat:");
                                    int seat1 = sc.nextInt();
                                    while (seat1 > 30) {
                                        System.out.println("This seat does not exist");
                                        seat1 = sc.nextInt();
                                    }
                                    for (int i = 0; i < Train.size(); ++i) {
                                        if (car3 == Train.get(i).getCar()) {
                                            if (seat1 == Train.get(i).getSeat()) {
                                                System.out.println("This seat is already taken ඞ");
                                                check = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (check == false) {
                                        Train.add(new Train(name, car3, seat1));
                                    }
                                    break;
                                case (3):
                                    System.out.println("Input seat:");
                                    int seat2 = sc.nextInt();
                                    while (seat2 > 50) {
                                        System.out.println("This seat does not exist");
                                        seat2 = sc.nextInt();
                                    }
                                    for (int i = 0; i < Train.size(); ++i) {
                                        if (car3 == Train.get(i).getCar()) {
                                            if (seat2 == Train.get(i).getSeat()) {
                                                System.out.println("This seat is already taken ඞ");
                                                check = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (check == false) {
                                        Train.add(new Train(name, car3, seat2));
                                    }
                                    break;
                                case (0):
                                    exit = false;
                                    break;
                                default:
                                    System.out.println("Incorrect choice, try again");
                            }
                        case (0):
                            exit = false;
                            break;
                        default:
                            System.out.println("Incorrect choice, try again");
                    }
                    break;
                case (2):
                    System.out.println("Input car:");
                    int delcar=sc.nextInt();
                    while(delcar>10){
                        System.out.println("This car does not exist");
                        delcar=sc.nextInt();
                    }
                    System.out.println("Input seat:");
                    int delseat=sc.nextInt();
                    while(delseat>20){
                        System.out.println("This seat does not exist");
                        delseat=sc.nextInt();
                    }
                    for(int i=0;i<Train.size();++i){
                        if(delcar==Train.get(i).getCar()){
                            if (delseat == Train.get(i).getSeat()){
                                Train.remove(i);
                                System.out.println("Removed");
                                break;
                            }
                            else{
                                System.out.println("Place is free\n");
                                break;
                            }
                        }
                        else{
                            System.out.println("Place is free\n");
                            break;
                        }
                    }
                    break;
                case (3):
                    for(Train el: Train){
                        System.out.print(el.getName()+" ");
                        System.out.print(el.getCar()+" ");
                        System.out.println(el.getSeat());
                    }
                    break;
                case (0):
                    exit = false;
                    break;
                default:
                    System.out.println("Incorrect choice, try again");
            }
        }
    }
}